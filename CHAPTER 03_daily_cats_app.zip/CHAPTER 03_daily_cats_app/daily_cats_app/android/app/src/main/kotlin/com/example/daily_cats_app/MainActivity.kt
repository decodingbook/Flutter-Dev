package com.example.daily_cats_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
